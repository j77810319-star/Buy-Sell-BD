import { Controller, Get } from '@nestjs/common';

@Controller('health')
export class HealthController {
  @Get()
  health() {
    return { status: 'ok', app: 'Buy Sell BD API', version: '0.1.0' };
  }
}
