import { Body, Controller, Get, Post, BadRequestException } from '@nestjs/common';
import { ListingsService } from './listings.service';

@Controller('listings')
export class ListingsController {
  constructor(private readonly listings: ListingsService) {}

  @Get()
  findAll() {
    return this.listings.findAll();
  }

  // Starter only: add DTO validation, authentication, authorization and database persistence before public launch.
  @Post()
  create(@Body() body: any) {
    const title = typeof body?.title === 'string' ? body.title.trim() : '';
    const description = typeof body?.description === 'string' ? body.description.trim() : '';
    const category = typeof body?.category === 'string' ? body.category.trim() : '';
    const location = typeof body?.location === 'string' ? body.location.trim() : '';
    const price = Number(body?.price);
    if (!title || !description || !category || !location || !Number.isFinite(price) || price < 0) {
      throw new BadRequestException('title, description, non-negative price, category and location are required');
    }
    return this.listings.create({ title, description, price, category, location });
  }
}
