import { Injectable } from '@nestjs/common';

export type Listing = {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  location: string;
  createdAt: string;
};

@Injectable()
export class ListingsService {
  // Demo memory store. Replace with PostgreSQL entities/repository before production.
  private listings: Listing[] = [
    {
      id: 'demo-1',
      title: 'ব্যবহৃত স্মার্টফোন',
      description: 'ভালো অবস্থায় আছে — ডেমো বিজ্ঞাপন',
      price: 8500,
      category: 'ইলেকট্রনিক্স',
      location: 'ঢাকা',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'demo-2',
      title: 'সাইকেল বিক্রি হবে',
      description: 'দৈনন্দিন ব্যবহারের জন্য',
      price: 4200,
      category: 'খেলাধুলা ও শখ',
      location: 'চট্টগ্রাম',
      createdAt: new Date().toISOString(),
    },
  ];

  findAll() {
    return this.listings;
  }

  create(input: Omit<Listing, 'id' | 'createdAt'>) {
    const listing: Listing = {
      ...input,
      id: `demo-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    this.listings.unshift(listing);
    return listing;
  }
}
