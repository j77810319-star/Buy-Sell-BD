# Payment integration — নিরাপদ পরবর্তী ধাপ

bKash/Nagad live integration এখানে এখনো implement করা হয়নি। কারণ credentials এবং merchant onboarding ছাড়া বাস্তব payment flow চালু করা যাবে না।

Backend-এ আলাদা provider service তৈরি করুন, যা official provider docs অনুযায়ী:
- payment initiate করবে
- server-to-server execute/verify করবে
- provider callback যাচাই করবে
- unique transaction ID এবং idempotency সংরক্ষণ করবে
- payment state `pending/success/failed/cancelled/refunded` হিসেবে রাখবে
- audit log ও reconciliation সমর্থন করবে

কখনো API secret mobile app বা web frontend-এ রাখবেন না। Browser redirect-কে payment confirmation হিসেবে বিশ্বাস করবেন না।
