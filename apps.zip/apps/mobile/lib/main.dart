import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const BanglaBazarApp());

class BanglaBazarApp extends StatelessWidget {
  const BanglaBazarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'বাই সেল বিডি',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087F5B)), useMaterial3: true),
      home: const MarketplaceHome(),
    );
  }
}

class MarketplaceHome extends StatefulWidget {
  const MarketplaceHome({super.key});
  @override
  State<MarketplaceHome> createState() => _MarketplaceHomeState();
}

class _MarketplaceHomeState extends State<MarketplaceHome> {
  bool english = false;
  bool loading = true;
  String search = '';
  String? error;
  List<dynamic> listings = [];

  // Android emulator uses 10.0.2.2 to reach the host machine.
  // For a deployed API, replace this with the HTTPS API URL.
  static const apiBase = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3001/api');

  @override
  void initState() {
    super.initState();
    fetchListings();
  }

  Future<void> fetchListings() async {
    try {
      final response = await http.get(Uri.parse('$apiBase/listings')).timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) throw Exception('HTTP ${response.statusCode}');
      setState(() { listings = jsonDecode(response.body) as List<dynamic>; loading = false; });
    } catch (_) {
      setState(() { error = english ? 'Could not connect to API.' : 'API-তে সংযোগ করা যায়নি।'; loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = english ? 'Buy Sell BD' : 'বাই সেল বিডি';
    final tagline = english ? 'Buying and selling made easy' : 'কেনাবেচা হোক সহজ';
    final filtered = listings.where((x) => '${x['title']} ${x['description']} ${x['category']} ${x['location']}'.toString().toLowerCase().contains(search.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        actions: [TextButton(onPressed: () => setState(() => english = !english), child: Text(english ? 'বাংলা' : 'English'))],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(english ? 'Ad posting form is coming next.' : 'পরবর্তী ধাপে বিজ্ঞাপন পোস্টের ফর্ম যোগ হবে।'))),
        icon: const Icon(Icons.add),
        label: Text(english ? 'Post ad' : 'বিজ্ঞাপন দিন'),
      ),
      body: RefreshIndicator(
        onRefresh: fetchListings,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(color: const Color(0xFFE5F5EC), borderRadius: BorderRadius.circular(20)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tagline, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 14),
              TextField(decoration: InputDecoration(hintText: english ? 'What are you looking for?' : 'কী খুঁজছেন?', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)), onChanged: (v) => setState(() => search = v)),
            ]),
          ),
          const SizedBox(height: 22),
          Text(english ? 'Popular categories' : 'জনপ্রিয় ক্যাটাগরি', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final c in (english ? ['Mobiles', 'Cars', 'Property', 'Jobs', 'Electronics', 'Fashion'] : ['মোবাইল', 'গাড়ি', 'সম্পত্তি', 'চাকরি', 'ইলেকট্রনিক্স', 'ফ্যাশন']))
              ActionChip(label: Text(c), onPressed: () => setState(() => search = c)),
          ]),
          const SizedBox(height: 22),
          Text(english ? 'Latest listings' : 'সাম্প্রতিক বিজ্ঞাপন', style: Theme.of(context).textTheme.titleLarge),
          if (loading) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
          if (error != null) Padding(padding: const EdgeInsets.all(16), child: Text(error!, style: const TextStyle(color: Colors.red))),
          for (final item in filtered) Card(
            margin: const EdgeInsets.only(top: 10),
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.shopping_bag_outlined)),
              title: Text('${item['title']}'),
              subtitle: Text('${item['category']} • ${item['location']}\n${item['description']}'),
              isThreeLine: true,
              trailing: Text('৳ ${item['price']}'),
            ),
          ),
          if (!loading && error == null && filtered.isEmpty) Padding(padding: const EdgeInsets.all(20), child: Text(english ? 'No listings found.' : 'কোনো বিজ্ঞাপন পাওয়া যায়নি।')),
          const SizedBox(height: 90),
        ]),
      ),
    );
  }
}
