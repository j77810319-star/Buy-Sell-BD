import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'বাই সেল বিডি | Buy Sell BD',
  description: 'বাংলাদেশে সহজে কেনাবেচা করুন',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="bn"><body>{children}</body></html>;
}
