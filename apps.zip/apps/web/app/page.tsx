'use client';

import { useEffect, useState } from 'react';

type Listing = {
  id: string; title: string; description: string; price: number;
  category: string; location: string; createdAt: string;
};

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api';

export default function Home() {
  const [lang, setLang] = useState<'bn' | 'en'>('bn');
  const [listings, setListings] = useState<Listing[]>([]);
  const [query, setQuery] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    fetch(`${API}/listings`)
      .then((r) => { if (!r.ok) throw new Error('API request failed'); return r.json(); })
      .then(setListings)
      .catch(() => setError('API এখন পাওয়া যাচ্ছে না। API server চালু আছে কি না দেখুন।'));
  }, []);

  const t = lang === 'bn'
    ? { tagline: 'কেনাবেচা হোক সহজ', search: 'কী খুঁজছেন?', categories: 'জনপ্রিয় ক্যাটাগরি', latest: 'সাম্প্রতিক বিজ্ঞাপন', post: 'বিজ্ঞাপন দিন', all: 'সব বিজ্ঞাপন' }
    : { tagline: 'Buying and selling made easy', search: 'What are you looking for?', categories: 'Popular categories', latest: 'Latest listings', post: 'Post an ad', all: 'All listings' };

  const filtered = listings.filter((x) => `${x.title} ${x.description} ${x.category} ${x.location}`.toLowerCase().includes(query.toLowerCase()));
  const categories = lang === 'bn'
    ? ['মোবাইল ও ট্যাবলেট', 'গাড়ি', 'বাসা ও সম্পত্তি', 'চাকরি', 'ইলেকট্রনিক্স', 'ফ্যাশন']
    : ['Mobiles & Tablets', 'Cars', 'Property', 'Jobs', 'Electronics', 'Fashion'];

  return (
    <main className="page">
      <header className="topbar">
        <a className="brand" href="/">বাই সেল বিডি<span>Buy Sell BD</span></a>
        <div className="actions">
          <button className="language" onClick={() => setLang(lang === 'bn' ? 'en' : 'bn')}>{lang === 'bn' ? 'English' : 'বাংলা'}</button>
          <button className="post" onClick={() => alert(lang === 'bn' ? 'বিজ্ঞাপন পোস্ট করার ফর্ম পরবর্তী ধাপে যোগ হবে।' : 'The listing form will be added in the next step.')}>{t.post}</button>
        </div>
      </header>
      <section className="hero">
        <div className="eyebrow">BANGLA BAZAR MARKETPLACE</div>
        <h1>{t.tagline}</h1>
        <p>{lang === 'bn' ? 'আপনার এলাকার পণ্য খুঁজুন, বিজ্ঞাপন দেখুন এবং সহজে যোগাযোগ করুন।' : 'Discover local products, browse listings, and connect with sellers.'}</p>
        <input aria-label={t.search} placeholder={t.search} value={query} onChange={(e) => setQuery(e.target.value)} />
      </section>
      <section>
        <h2>{t.categories}</h2>
        <div className="categories">{categories.map((c, i) => <button key={c} className="category" onClick={() => setQuery(['মোবাইল','গাড়ি','বাসা','চাকরি','ইলেকট্রনিক্স','ফ্যাশন'][i])}><span>{['📱','🚗','🏠','💼','💻','👕'][i]}</span>{c}</button>)}</div>
      </section>
      <section>
        <div className="section-head"><h2>{t.latest}</h2><span>{filtered.length} {lang === 'bn' ? 'টি' : 'items'}</span></div>
        {error && <p className="error">{error}</p>}
        <div className="listings">
          {filtered.map((item) => <article className="listing" key={item.id}>
            <div className="placeholder">🛍️</div>
            <div className="listing-body"><span className="tag">{item.category}</span><h3>{item.title}</h3><p>{item.description}</p><strong>৳ {item.price.toLocaleString('en-BD')}</strong><small>📍 {item.location}</small></div>
          </article>)}
          {!error && filtered.length === 0 && <p>{lang === 'bn' ? 'কোনো বিজ্ঞাপন পাওয়া যায়নি।' : 'No listings found.'}</p>}
        </div>
      </section>
      <footer>© {new Date().getFullYear()} বাই সেল বিডি · {lang === 'bn' ? 'নিরাপদ কেনাবেচার পথে' : 'A simpler way to trade'}</footer>
    </main>
  );
}
